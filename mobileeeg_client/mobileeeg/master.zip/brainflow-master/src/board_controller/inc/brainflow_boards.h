#pragma once

#include "json.hpp"

using json = nlohmann::json;

extern json brainflow_boards_json;
