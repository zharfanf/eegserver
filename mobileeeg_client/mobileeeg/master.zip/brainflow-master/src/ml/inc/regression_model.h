#pragma once


extern const double regression_coefficients[10];
extern double regression_intercept;
