
#pragma once

extern double brainflow_focus_x[45889][10];
extern int brainflow_focus_y[45889];
