#pragma once


extern const double lda_coefficients[10];
extern double lda_intercept;
