#pragma once

double get_timestamp ();
