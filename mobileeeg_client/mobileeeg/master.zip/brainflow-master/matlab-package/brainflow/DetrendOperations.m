classdef DetrendOperations < int32
    % Store possible detrend operations 
    enumeration
        NONE(0)
        CONSTANT(1)
        LINEAR(2)
    end
end