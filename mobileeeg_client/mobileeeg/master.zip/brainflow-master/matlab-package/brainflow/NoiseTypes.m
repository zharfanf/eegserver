classdef NoiseTypes < int32
    % Store noise types
    enumeration
        FIFTY(0)
        SIXTY(1)
    end
end