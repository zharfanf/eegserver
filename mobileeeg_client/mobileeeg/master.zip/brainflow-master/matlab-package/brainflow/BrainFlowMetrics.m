classdef BrainFlowMetrics < int32
    % Store all supported metrics
    enumeration
        RELAXATION(0)
        CONCENTRATION(1)
        USER_DEFINED(2)
    end
end