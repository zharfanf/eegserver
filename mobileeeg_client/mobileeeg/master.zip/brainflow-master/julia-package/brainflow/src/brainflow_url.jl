# TODO: automatically generate by brainflow CICD
function brainflow_url()
    url = "https://github.com/brainflow-dev/brainflow/releases/download/4.8.1/compiled_libs.tar"
    return url
end