module brainflow
{
    exports brainflow;

    requires java.sql;
    requires transitive commons.lang3;
    requires transitive commons.math3;
    requires gson;
    requires jna;
}
