# BrainFlow tests

Tests for java, C# and Matlab located mostly inside:

* [java-package](../java-package/brainflow/)
* [Csharp-package](../csharp-package/brainflow/)
* [matlab-package](../matlab-package/brainflow/)
* [julia-package](../julia-package/brainflow/test)
* [rust-package](../rust-package/brainflow/examples/)

Because for these bindings its much easier.
